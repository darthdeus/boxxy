﻿namespace Boxxy.Screens
{
    internal interface IScreen
    {
        void Run();
    }
}