﻿using System;

namespace Boxxy
{
    public class QuitMenu : Exception
    {
    }
}